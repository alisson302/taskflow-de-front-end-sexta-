export function tasksReducer(state, action) {
  switch (action.type) {
    case "ADD":
      // Lista nova = tudo que já tinha + uma tarefa nova
      return [
        ...state,
        { id: Date.now(), texto: action.texto, concluida: false },
      ];

    case "TOGGLE":
      // Na tarefa com o id pedido, inverte "concluida". As outras ficam iguais.
      return state.map((tarefa) =>
        tarefa.id === action.id
          ? { ...tarefa, concluida: !tarefa.concluida }
          : tarefa
      );

    case "REMOVE":
      // Fica só com as tarefas de id diferente do pedido
      return state.filter((tarefa) => tarefa.id !== action.id);

    case "SET":
      // Troca a lista inteira
      return action.tarefas;

    default:
      return state;
  }
}